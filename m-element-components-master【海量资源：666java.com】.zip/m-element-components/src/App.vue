<template>
  <router-view></router-view>
</template>


<style lang='scss'>
@import "./styles/base";
@import "./styles/ui";
.notification-popper-class {
  padding: 0 !important;
}
</style>