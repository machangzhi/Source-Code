<template>
  <div class="container">
    <h1>vue3 + typescript + vite2 + element-plus二次封装组件</h1>
  </div>
</template>

<script lang='ts' setup>
</script>

<style lang='scss' scoped>
  .container {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    h1 {
      font-size: 40px;
      position: relative;
      top: -100px;
    }
  }
</style>