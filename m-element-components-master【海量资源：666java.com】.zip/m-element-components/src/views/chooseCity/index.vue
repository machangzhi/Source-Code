<template>
  <m-choose-city></m-choose-city>
</template>

<script lang='ts' setup>
</script>

<style lang='scss' scoped>
</style>