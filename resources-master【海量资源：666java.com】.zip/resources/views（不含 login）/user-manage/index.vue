<template>
  <div class="">用户管理</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped></style>
