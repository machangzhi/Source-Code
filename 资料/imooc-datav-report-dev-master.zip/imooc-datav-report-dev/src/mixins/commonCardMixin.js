import CommonCard from '../components/CommonCard/index'

export default {
  components: {
    CommonCard
  }
}
