import Vue from 'vue'
import VCharts from 'v-charts'
import 'v-charts/lib/style.css'

Vue.use(VCharts)
